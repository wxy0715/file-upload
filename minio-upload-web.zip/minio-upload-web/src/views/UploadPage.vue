<template>
    <el-card style="width: 80%; margin: 80px auto" header="文件分片上传">
        <el-upload
            class="upload-demo"
            drag
            action="/"
            multiple
            :http-request="handleHttpRequest"
            :on-remove="handleRemoveFile">
            <el-icon class="el-icon--upload"><upload-filled /></el-icon>
            <div class="el-upload__text">
                请拖拽文件到此处或 <em>点击此处上传</em>
            </div>
        </el-upload>
    </el-card>
</template>


<script setup>
import { UploadFilled } from '@element-plus/icons-vue'
import md5 from "../lib/md5";
import { initPart, checkPart, uploadPart,mergePart} from '../lib/api';
import {ElNotification} from "element-plus";
/**
 * el-upload 自定义上传方法入口
 */
const handleHttpRequest = async (options) => {
    const file = options.file
    const fileName = file.name
    const totalSize = file.size
    const identifier = await md5(file)
    // 初始化任务
    var { code, data,description } = await initPart({
        "originalFilename": fileName,
        "md5": identifier,
        "length": totalSize,
    })
    if (code !== "00000") {
        ElNotification({
            title: '失败',
            message: description,
            type: 'error',
        })
        return
    }
    const fileInfo = data[0];
    console.log("初始化任务",fileInfo);
    // 判断文件是否已经上传过
    if(fileInfo.uploadStatus === 2) {
        ElNotification({
            title: '成功',
            message: '文件上传成功',
            type: 'success',
        })
        return
    }
    // 切割文件
    const chunkSize = 1024 * 1024 * 5
    const chunks = []
    for (let i = 0; i < totalSize; i += chunkSize) {
        const chunk = file.slice(i, i + chunkSize)
        chunks.push(chunk)
    }
    // 创建分片上传队列
    for (let index = 0; index < chunks.length; index++) {
        const file = chunks[index];
        // 判断此分片是否已经上传过
        var { code, data,description } = await checkPart({
            "url": fileInfo.url,
            "index": index + 1
        })
        if (code !== "00000") {
            ElNotification({
                title: '失败',
                message: description,
                type: 'error',
            })
            return
        }
        console.log("分片",index + 1,"是否已经上传过:", data[0]?'是':'否');
        if (data[0]) {
            continue
        }
        // 上传分片
        let formdata = new FormData();
        formdata.append("file", file);
        formdata.append("index", index + 1);
        formdata.append("url", fileInfo.url);
        var { code, data,description } = await uploadPart(formdata)
        if (code !== "00000") {
            ElNotification({
                title: '失败',
                message: description,
                type: 'error',
            })
            return
        }
        console.log("上传分片:",index + 1,"成功");
    }
    // 合并分片
    console.log("开始合并分片");
    var { code, data,description } = await mergePart({
        "url": fileInfo.url
    })
    if (code !== "00000") {
        ElNotification({
            title: '失败',
            message: description,
            type: 'error',
        })
        return
    }
    console.log("合并分片成功");
    ElNotification({
        title: '成功',
        message: '上传成功',
        type: 'success',
    })
}


/**
 * 移除文件列表中的文件
 * 如果文件存在上传队列任务对象，则停止该队列的任务
 */
const handleRemoveFile = (uploadFile, uploadFiles) => {
}

</script>